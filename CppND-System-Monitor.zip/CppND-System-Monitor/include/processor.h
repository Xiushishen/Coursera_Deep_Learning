#ifndef PROCESSOR_H
#define PROCESSOR_H

#include <unistd.h>
#include "linux_parser.h"
#include <chrono>
#include <thread>
#include <vector>

class Processor {
 public:
  float Utilization();  // TODO: See src/processor.cpp
  // TODO: Declare any necessary private members
 private:
};

#endif