#ifndef PROCESSOR_H
#define PROCESSOR_H

#include <unistd.h>
#include "linux_parser.h"
#include <string>


class Processor {
 public:
  float Utilization();
  long prev_idle_ = 0;
  long prev_total_ = 0;
 private:
    std::string line, cpu;
    std::string user, nice, system, idle, iowait, irq, softirq, steal, guest, guest_nice;
    float util = 0;
};

#endif