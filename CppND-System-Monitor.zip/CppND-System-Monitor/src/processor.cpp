#include "processor.h"
#include <iostream>

// TODO: Return the aggregate CPU utilization
float Processor::Utilization() {
    long idle_prev = LinuxParser::IdleJiffies();
    long total_prev = LinuxParser::Jiffies();
    std::this_thread::sleep_for(std::chrono::seconds(1));
    long idle_now = LinuxParser::IdleJiffies();
    long total_now = LinuxParser::Jiffies();
    float total_dif = static_cast<float>(total_now - total_prev);
    float idle_dif = static_cast<float>(idle_now - idle_prev);

    if (total_dif == 0.0)
    {
        std::cerr << "Failed to read Jiffies data." << std::endl;
        return 0;
    }
    else
    {
        return (total_dif - idle_dif) / total_dif;
    }
}
