#include <dirent.h>
#include <unistd.h>
#include <sstream>
#include <string>
#include <vector>

#include "linux_parser.h"

using std::stof;
using std::string;
using std::to_string;
using std::vector;

string LinuxParser::OperatingSystem() {
  string line;
  string key;
  string value;
  std::ifstream filestream(kOSPath);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::replace(line.begin(), line.end(), ' ', '_');
      std::replace(line.begin(), line.end(), '=', ' ');
      std::replace(line.begin(), line.end(), '"', ' ');
      std::istringstream linestream(line);
      while (linestream >> key >> value) {
        if (key == "PRETTY_NAME") {
          std::replace(value.begin(), value.end(), '_', ' ');
          return value;
        }
      }
    }
  }
  return value;
}

string LinuxParser::Kernel() {
  string os, kernel, version;
  string line;
  std::ifstream stream(kProcDirectory + kVersionFilename);
  if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> os >> version >> kernel;
  }
  return kernel;
}

vector<int> LinuxParser::Pids() {
  vector<int> pids;
  DIR* directory = opendir(kProcDirectory.c_str());
  struct dirent* file;
  while ((file = readdir(directory)) != nullptr) {
    // Is this a directory?
    if (file->d_type == DT_DIR) {
      // Is every character of the name a digit?
      string filename(file->d_name);
      if (std::all_of(filename.begin(), filename.end(), isdigit)) {
        int pid = stoi(filename);
        pids.push_back(pid);
      }
    }
  }
  closedir(directory);
  return pids;
}

float LinuxParser::MemoryUtilization() {
  float totalMemory, freeMemory;
  string line, key;
  float value;
  std::ifstream filestream(kProcDirectory + kMeminfoFilename);
    if(filestream.is_open()) {
      while (std::getline(filestream, line)) {
        std::istringstream linestream(line);
          while(linestream >> key >> value) {
            if(key == "MemTotal:") {
              totalMemory = value;
            }
            else if(key == "MemFree:") {
              freeMemory = value;
            }
          }
        }
        filestream.close();
      }
    return (totalMemory-freeMemory) / totalMemory; 
}

long LinuxParser::UpTime() 
{
  string line;
  string uptime, idle_process_time;
  std::ifstream stream(kProcDirectory + kUptimeFilename);
  if (stream.is_open())
  {
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> uptime >> idle_process_time;
    stream.close();
    return std::stol(uptime);
  }
  return 0;
}

long LinuxParser::Jiffies() {
  long res;
  res = ActiveJiffies() + IdleJiffies();
  return res;
}

long LinuxParser::ActiveJiffies(int pid) {
  string line;
  string value;
  vector<string> jiffies;
  std::ifstream filestream(kProcDirectory + std::to_string(pid) + kStatFilename);
  if (filestream.is_open())
  {
    std::getline(filestream, line);
    std::istringstream linestream(line);
    while (linestream >> value)
    {
      jiffies.emplace_back(value);
    }
    filestream.close();
    return (std::stol(jiffies[13]) + std::stol(jiffies[14]) + std::stol(jiffies[15]) + std::stol(jiffies[16])) / sysconf(_SC_CLK_TCK);
  }
  else
  {
    return 0;
  }
}

long LinuxParser::ActiveJiffies() { 
  long res;
  vector<string> jiffies = LinuxParser::CpuUtilization();
  if (jiffies.size() > 0)
  {
    res = std::stol(jiffies[CPUStates::kUser_]) + std::stol(jiffies[CPUStates::kNice_])
          + std::stol(jiffies[CPUStates::kSystem_]) + std::stol(jiffies[CPUStates::kIRQ_])
          + std::stol(jiffies[CPUStates::kSoftIRQ_]) + std::stol(jiffies[CPUStates::kSteal_]);
    return res; 
  }
  else
  {
    return 0;
  }
}

long LinuxParser::IdleJiffies() {
  long res;
  vector<string> jiffies = LinuxParser::CpuUtilization();
  if (jiffies.size() > 0)
  {
    res = std::stol(jiffies[CPUStates::kIdle_]) + std::stol(jiffies[CPUStates::kIOwait_]);
    return res; 
  }
  else
  {
    return 0;
  }
}

vector<string> LinuxParser::CpuUtilization() 
{ 
  string line;
  string cpu, value;
  vector<string> jiffies;
  std::ifstream filestream(kProcDirectory + kStatFilename);
  if (filestream.is_open())
  {
    std::getline(filestream, line);
    std::istringstream linestream(line);
    linestream >> cpu;
    while (linestream >> value)
    {
      jiffies.push_back(value);
    }
  }
  return jiffies;
}

float LinuxParser::CpuUtilization(int pid) {
  long seconds = LinuxParser::UpTime(pid);
  long totaltime = LinuxParser::ActiveJiffies(pid);
  float utilization_ = float(totaltime) / float(seconds);
  return utilization_;
}

int LinuxParser::TotalProcesses() {
  string line;
  string name, value;
  std::ifstream filestream(kProcDirectory + kStatFilename);
  if (filestream.is_open())
  {
    while (std::getline(filestream, line))
    {
      std::istringstream linestream(line);
      linestream >> name >> value;
      if (name == "processes")
      {
        return std::stoi(value);
      }
    }
  }
  return 0;    
}

int LinuxParser::RunningProcesses() {
  string line;
  string name, value;
  std::ifstream filestream(kProcDirectory + kStatFilename);
  if (filestream.is_open())
  {
    while (std::getline(filestream, line))
    {
      std::istringstream linestream(line);
      linestream >> name >> value;
      if (name == "procs_running")
      {
        return std::stoi(value);
      }
    }
  }
  return 0;    
}

string LinuxParser::Command(int pid) {
  string line;
  string value;
  std::ifstream filestream(kProcDirectory + std::to_string(pid) + kCmdlineFilename);
  if (filestream.is_open())
  {
    std::getline(filestream, line);
    std::istringstream linestream(line);
    linestream >> value;
    return value;
  }
  return string();
}

string LinuxParser::Ram(int pid) { 
  string line;
  string name, value;
  long res;
  std::ifstream filestream(kProcDirectory + std::to_string(pid) + kStatusFilename);
  if (filestream.is_open())
  {
    while (std::getline(filestream, line))
    {
      std::istringstream linestream(line);
      while (linestream >> name >> value) {
        if (name == "VmRSS:") // replace the VmSize with VmRSS.
        {
          res = std::stol(value) / 1024;
          break;
        }
      }    
    }
    filestream.close();
  }
  return to_string(res);
}

string LinuxParser::Uid(int pid) {
  string line;
  string value, name;
  std::ifstream filestream(kProcDirectory + std::to_string(pid) + kStatusFilename);
  if (filestream.is_open())
  {
    while (std::getline(filestream, line))
    {
      std::istringstream linestream(line);
      linestream >> name >> value;
      if (name == "Uid:")
      {
        return value;
      }
    }
  }
  return string();
}

string LinuxParser::User(int pid) { 
  string line;
  string user, char_, value;
  std::ifstream filestream(kPasswordPath);
  if (filestream.is_open())
  {
    while (std::getline(filestream, line))
    {
      std::replace(line.begin(), line.end(), ':', ' ');
      std::istringstream linestream(line);
      linestream >> user >> char_ >> value;
      if (value == LinuxParser::Uid(pid))
      {
        break;
      }
    }
  }
  return user;
}

long LinuxParser::UpTime(int pid) {
  string line;
  string name, value;
  std::ifstream filestream(kProcDirectory + std::to_string(pid) + kStatFilename);
  if (filestream.is_open())
  {
    std::getline(filestream, line);
    std::istringstream linestream(line);
    for (int i = 0; i < 22; i++)
    {
      linestream >> value;
    }
    return std::stol(value) / sysconf(_SC_CLK_TCK);
  }
  return 0;
}
